<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Paiement;
use App\Models\PaymentSchedule;
use App\Models\Client;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PaymentController extends Controller
{
    /**
     * Afficher la liste des paiements
     */
    public function index(Request $request)
    {
        try {
            $user = $request->user();
            $query = Paiement::query();

            // Filtrage par statut
            if ($request->has('status')) {
                $status = $request->status;
                if ($status !== 'all') {
                    $query->where('status', $status);
                }
            }

            // Filtrage par type
            if ($request->has('type')) {
                $query->where('type', $request->type);
            }

            // Filtrage par date - Le frontend envoie start_date et end_date
            if ($request->has('start_date')) {
                $query->where('date_paiement', '>=', $request->start_date);
            } elseif ($request->has('date_debut')) {
                $query->where('date_paiement', '>=', $request->date_debut);
            }

            if ($request->has('end_date')) {
                $query->where('date_paiement', '<=', $request->end_date);
            } elseif ($request->has('date_fin')) {
                $query->where('date_paiement', '<=', $request->date_fin);
            }

            // Filtrage par client
            if ($request->has('client_id') && $request->client_id > 0) {
                $query->where('client_id', $request->client_id);
            }

            // Filtrage par comptable
            if ($request->has('comptable_id') && $request->comptable_id > 0) {
                $query->where('comptable_id', $request->comptable_id);
            }

            // Si comptable → filtre ses propres paiements
            if ($user->role == 3) { // Comptable
                $query->where('comptable_id', $user->id);
            }

            // Si patron → tous les paiements
            // Sinon, filtre par rôle

            // Pagination
            $perPage = $request->get('per_page', 15);
            $payments = $query->orderBy('date_paiement', 'desc')->paginate($perPage);

            // Transformer les paiements pour le frontend
            $payments->getCollection()->transform(function ($payment) {
                return $this->formatPaymentForFrontend($payment);
            });

            return response()->json([
                'success' => true,
                'data' => $payments->items(),
                'current_page' => $payments->currentPage(),
                'last_page' => $payments->lastPage(),
                'per_page' => $payments->perPage(),
                'total' => $payments->total(),
                'message' => 'Liste des paiements récupérée avec succès'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération des paiements: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Créer un paiement
     */
    public function store(Request $request)
    {
        try {
            $user = $request->user();

            // Validation des données
            $validated = $request->validate([
                'client_id' => 'nullable|integer|exists:clients,id',
                'client_name' => 'required|string|max:255',
                'client_email' => 'nullable|email|max:255',
                'client_address' => 'nullable|string',
                'comptable_id' => 'required|integer|exists:users,id',
                'comptable_name' => 'required|string|max:255',
                'type' => 'required|in:one_time,monthly',
                'payment_date' => 'required|date',
                'due_date' => 'nullable|date|after_or_equal:payment_date',
                'amount' => 'required|numeric|min:0.01',
                'payment_method' => 'required|in:bank_transfer,check,cash,card,direct_debit,virement,especes,cheque,carte_bancaire,mobile_money',
                'currency' => 'nullable|string|max:3',
                'description' => 'nullable|string',
                'notes' => 'nullable|string',
                'reference' => 'nullable|string|max:255',
                'schedule' => 'nullable|array'
            ]);

            // Si client_id est fourni, récupérer les infos du client
            $clientId = $validated['client_id'] ?? null;
            if ($clientId) {
                $client = Client::find($clientId);
                if ($client) {
                    $validated['client_name'] = $client->nom . ' ' . ($client->prenom ?? '');
                    $validated['client_email'] = $client->email ?? $validated['client_email'] ?? '';
                    $validated['client_address'] = $client->adresse ?? $validated['client_address'] ?? '';
                }
            }

            // Mapper payment_method du frontend vers le backend
            $paymentMethodMapping = [
                'bank_transfer' => 'virement',
                'check' => 'cheque',
                'cash' => 'especes',
                'card' => 'carte_bancaire',
                'direct_debit' => 'virement'
            ];
            $typePaiement = $paymentMethodMapping[$validated['payment_method']] ?? $validated['payment_method'];

            // Créer le paiement
            $paiement = Paiement::create([
                'payment_number' => Paiement::generatePaymentNumber(),
                'type' => $validated['type'],
                'client_id' => $clientId,
                'comptable_id' => $validated['comptable_id'],
                'client_name' => $validated['client_name'],
                'client_email' => $validated['client_email'] ?? null,
                'client_address' => $validated['client_address'] ?? null,
                'comptable_name' => $validated['comptable_name'],
                'date_paiement' => $validated['payment_date'],
                'due_date' => $validated['due_date'] ?? null,
                'montant' => $validated['amount'],
                'currency' => $validated['currency'] ?? 'FCFA',
                'type_paiement' => $typePaiement,
                'status' => 'draft',
                'description' => $validated['description'] ?? null,
                'notes' => $validated['notes'] ?? null,
                'reference' => $validated['reference'] ?? null,
                'user_id' => $user->id,
            ]);

            // Si c'est un paiement mensuel avec schedule, créer le schedule
            if ($validated['type'] === 'monthly' && isset($validated['schedule'])) {
                $scheduleData = $validated['schedule'];
                PaymentSchedule::create([
                    'payment_id' => $paiement->id,
                    'start_date' => $scheduleData['start_date'] ?? $validated['payment_date'],
                    'end_date' => $scheduleData['end_date'] ?? null,
                    'frequency' => $scheduleData['frequency'] ?? 30,
                    'total_installments' => $scheduleData['total_installments'] ?? 12,
                    'installment_amount' => $scheduleData['installment_amount'] ?? ($validated['amount'] / ($scheduleData['total_installments'] ?? 12)),
                    'status' => 'active'
                ]);
            }

            return response()->json([
                'success' => true,
                'data' => $this->formatPaymentForFrontend($paiement->fresh()),
                'message' => 'Paiement créé avec succès'
            ], 201);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur de validation',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la création du paiement: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Récupérer un paiement spécifique
     */
    public function show($id)
    {
        try {
            $payment = Paiement::findOrFail($id);

            return response()->json([
                'success' => true,
                'data' => $this->formatPaymentForFrontend($payment),
                'message' => 'Paiement récupéré avec succès'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération du paiement: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Formater un paiement pour le frontend
     */
    private function formatPaymentForFrontend($payment)
    {
        // Mapper type_paiement du backend vers le frontend
        $paymentMethodMapping = [
            'virement' => 'bank_transfer',
            'cheque' => 'check',
            'especes' => 'cash',
            'carte_bancaire' => 'card',
            'mobile_money' => 'direct_debit'
        ];
        $paymentMethod = $paymentMethodMapping[$payment->type_paiement] ?? $payment->type_paiement;

        $formatted = [
            'id' => $payment->id,
            'payment_number' => $payment->payment_number ?? 'N/A',
            'type' => $payment->type ?? 'one_time',
            'client_id' => $payment->client_id ?? 0,
            'client_name' => $payment->client_name ?? ($payment->client ? ($payment->client->nom . ' ' . ($payment->client->prenom ?? '')) : 'Client inconnu'),
            'client_email' => $payment->client_email ?? ($payment->client ? $payment->client->email : ''),
            'client_address' => $payment->client_address ?? ($payment->client ? $payment->client->adresse : ''),
            'comptable_id' => $payment->comptable_id ?? $payment->user_id ?? 0,
            'comptable_name' => $payment->comptable_name ?? ($payment->user ? ($payment->user->nom . ' ' . ($payment->user->prenom ?? '')) : 'Comptable inconnu'),
            'payment_date' => $payment->date_paiement ? $payment->date_paiement->format('Y-m-d') : null,
            'due_date' => $payment->due_date ? $payment->due_date->format('Y-m-d') : null,
            'status' => $payment->status ?? 'draft',
            'amount' => (float)($payment->montant ?? 0),
            'currency' => $payment->currency ?? 'FCFA',
            'payment_method' => $paymentMethod,
            'description' => $payment->description ?? '',
            'notes' => $payment->notes ?? $payment->commentaire ?? '',
            'reference' => $payment->reference ?? '',
            'submitted_at' => $payment->submitted_at ? $payment->submitted_at->format('Y-m-d H:i:s') : null,
            'approved_at' => $payment->approved_at ? $payment->approved_at->format('Y-m-d H:i:s') : null,
            'paid_at' => $payment->paid_at ? $payment->paid_at->format('Y-m-d H:i:s') : null,
            'created_at' => $payment->created_at ? $payment->created_at->format('Y-m-d H:i:s') : null,
            'updated_at' => $payment->updated_at ? $payment->updated_at->format('Y-m-d H:i:s') : null,
        ];

        // Ajouter le schedule si existe
        if ($payment->schedule) {
            $formatted['schedule'] = [
                'id' => $payment->schedule->id,
                'start_date' => $payment->schedule->start_date ? $payment->schedule->start_date->format('Y-m-d') : null,
                'end_date' => $payment->schedule->end_date ? $payment->schedule->end_date->format('Y-m-d') : null,
                'frequency' => $payment->schedule->frequency ?? 30,
                'total_installments' => $payment->schedule->total_installments ?? 12,
                'installment_amount' => (float)($payment->schedule->installment_amount ?? 0),
            ];
        }

        return $formatted;
    }
}
