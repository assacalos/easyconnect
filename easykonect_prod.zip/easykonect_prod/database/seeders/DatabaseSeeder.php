<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Les seeders ont été supprimés
        // Vous pouvez maintenant enregistrer vos propres données de test
    }
}
